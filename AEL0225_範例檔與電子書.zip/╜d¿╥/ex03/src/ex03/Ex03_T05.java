package ex03;

public class Ex03_T05 {

	public static void main(String[] args) {
		int num1=5;int num2=3;int total=10;
		if(num1 <= total && num2 < num1) {
			System.out.println("true");
		}
	}

}
