package ex03;

public class Ex03_T03 {

	public static void main(String[] args) {
		int num = 12;
		while (num < 10) {
			num--;
		}
		System.out.println(num);

	}

}
