package ex03;

public class Ex03_T01 {

	public static void main(String[] args) {
		String str = "null";
		if (str == null) {
			System.out.println("null");
			// } else (str.length() == 0) {
		} else if (str.length() == 0) {
			System.out.println("zero");
		} else {
			System.out.println("some");
		}
	}
}
