package ex05;

public class Score {
	public static void main(String[] args) {
		for (int i = 0; i < args.length; i++)
			System.out.println(" �y�� " + (i + 1) + " �P�Ǧ��Z�G" + args[i]);
	}
}
