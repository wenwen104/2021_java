package ex05;

public class Math {
	static void mul(int x, int y) {
		System.out.print(x + " * " + y + " = " + (x * y));
	}
	void div(int x, int y) {
		System.out.print(x + " / " + y + " = " + (x / y));
	}
}
