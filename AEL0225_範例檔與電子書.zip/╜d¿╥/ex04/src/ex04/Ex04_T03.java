package ex04;
public class Ex04_T03 {
	public static void main(String[] args) {
		int n1 = 15;
		int n2 = 25;
		int n3 = 35;
		int[] num = new int[] {n1,n2,n3};
		System.out.print(num[0] + "," + num[1] + "," + num[2]);
	}
}
