package ex04;
public class Ex04_T01 {
	public static void main(String[] args) {
		int[]x[] = { {1,2},{3,4,6},{6,7,8,9} };
		int[][]y = x;
		System.out.print(y[2][1]);
	}
}
