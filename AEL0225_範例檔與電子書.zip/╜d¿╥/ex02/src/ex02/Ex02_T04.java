package ex02;

public class Ex02_T04 {

	public static void main(String[] args) {
		//String #name ="Oracle Java";
		int $age = 17;
		Double _height = 100.5;
		//double �Vtemp = 50.5
		System.out.printf("$age=%d , _height=%f",$age,_height);
	}

}
