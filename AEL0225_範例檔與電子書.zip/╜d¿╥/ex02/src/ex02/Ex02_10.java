package ex02;
public class Ex02_10 {
	public static void main(String[] args) {
		int a = 10, b = 5;
		System.out.println("a = " + a + ", b = " + b);
		System.out.println("a | b = " + (a | b)); 
		boolean c = true, d = false;
		System.out.println("c = " + c + ", d = " + d);
		System.out.println("c | d = " + (c | d)); 
	}
}
