package ex02;

public class Ex02_T07 {

	public static void main(String[] args) {
		double num1 = 255.755;
		System.out.println("num1= " + num1);
		int num2 = (int)num1;
		System.out.println("num2= " + num2);
		byte num3 = (byte)num2;
		System.out.println("num3= " + num3);
	}

}
