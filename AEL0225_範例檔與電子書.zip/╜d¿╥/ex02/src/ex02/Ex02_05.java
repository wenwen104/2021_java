package ex02;
public class Ex02_05 {
	public static void main(String[] args) {
		int num1=10,num2=3;	// �ŧinum1�Mnum2������ܼ�
		System.out.println(num1 + " - " + num2 + " = " + (num1 - num2));
		System.out.println(num1 + " * " + num2 + " = " + (num1 * num2));
		System.out.println(num1 + " / " + num2 + " = " + (num1 / num2));
	}
}
