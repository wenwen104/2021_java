package ex02;
public class Ex02_09 {
	public static void main(String[] args) {
		byte a = 52,b = 15;
		System.out.println("a = " + a + ", b = " + b);
		System.out.println("~ a = " + ~a);
		System.out.println("a & b = " + (a & b));
		System.out.println("a | b = " + (a | b));
		System.out.println("a ^ b = " + (a ^ b));
	}
}
