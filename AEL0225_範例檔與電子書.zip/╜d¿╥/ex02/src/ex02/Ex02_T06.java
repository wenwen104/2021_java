package ex02;

public class Ex02_T06 {

	public static void main(String[] args) {
        short year = 1999;
        boolean married = false;
        char grade = 'B';
        float salary = 34567.5f;
        System.out.printf("��¾�~= %d, �w�B= %b, ����= %c, �~��= %f", 
        		year,married,grade,salary);
	}

}
