package ex02;
import java.util.Scanner;
public class Ex02_04 {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.print("�п�J��ơG");
		var inputData = scn.next();
		System.out.println("�z��J����ƬO "+ inputData);
		scn.close();
	}
}
